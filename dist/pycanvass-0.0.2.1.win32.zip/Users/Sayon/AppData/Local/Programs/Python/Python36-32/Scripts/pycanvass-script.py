#!C:\Users\Sayon\AppData\Local\Programs\Python\Python36-32\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'pycanvass==0.0.2.1','console_scripts','pycanvass'
__requires__ = 'pycanvass==0.0.2.1'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('pycanvass==0.0.2.1', 'console_scripts', 'pycanvass')()
    )
