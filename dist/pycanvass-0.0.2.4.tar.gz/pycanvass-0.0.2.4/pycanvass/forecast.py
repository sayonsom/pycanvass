def forecast(name, filename, horizon):
    print("[x]")