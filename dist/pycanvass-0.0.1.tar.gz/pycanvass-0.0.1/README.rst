PyCanvass is an open source simulation software for computing resiliency of Smart Grid and power systems critical infrastructure.
It has a unique resiliency computation engine, and it enables integration with other industry-standard power system simulation software like GridLAB-D, and Real-Time Digital Simulators.

PyCanvass was developed by Sayonsom Chanda, at Washington State University - and is still maintained by him. If you have any questions, or find bugs - please email: sayon@ieee.org

Please contribute to the project.


